package com.example.application1.DAO;

import java.util.List;

import com.example.application1.DTO.Person;

public interface IPersonDAO {

    public  List<Person> getPersons();

    public void addPerson(Person person);

    public void removePerson(Person person);

}
