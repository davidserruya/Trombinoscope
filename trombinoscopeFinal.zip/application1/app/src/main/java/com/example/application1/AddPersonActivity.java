package com.example.application1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.application1.DAO.IPersonDAO;
import com.example.application1.DTO.Person;
import com.example.application1.DAO.PersonDAOData;

public class AddPersonActivity extends AppCompatActivity {
    private static final String TAG = "AddPersonActivity";

    EditText    prenom;
    EditText    nom;
    Button      btnAddPerson;

    IPersonDAO personDAO;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        personDAO  = new PersonDAOData();

        setContentView(R.layout.activity_add_person);
        prenom = (EditText) findViewById(R.id.prenom);
        nom  = (EditText) findViewById(R.id.nom);

        btnAddPerson = (Button) findViewById(R.id.add_person);
        btnAddPerson.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Person person = new Person(prenom.getText().toString(), nom.getText().toString(), Color.RED);
                personDAO.addPerson(person);
                Toast.makeText(getApplicationContext(), "ajout ok ", Toast.LENGTH_LONG).show();

                prenom.setText("");
                nom.setText("");
            }
        });
    }

}
